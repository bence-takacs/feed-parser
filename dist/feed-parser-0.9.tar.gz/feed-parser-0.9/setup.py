from setuptools import setup
import requests
import bs4
import logging

setup(
    name='feed-parser',
    version='0.9',
    scripts=['fp.py'],
    install_requires=[
        'requests',
        'bs4',
        'logging'
    ]
)